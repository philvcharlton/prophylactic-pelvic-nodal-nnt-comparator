const assert = require("node:assert/strict");
const test = require("node:test");
const nnt = require("../src/nnt-calculations.js");

const close = (actual, expected, tolerance = 0.01) => assert.ok(Math.abs(actual - expected) <= tolerance, `${actual} != ${expected}`);

test("POP-RT point estimates reproduce the published-display calculations", () => {
  close(nnt.calculateEffect({ measure: "survival", comparatorRate: 81.2, treatmentRate: 95.0 }).exact, 7.25);
  close(nnt.calculateEffect({ measure: "survival", comparatorRate: 77.2, treatmentRate: 89.5 }).exact, 8.13);
  close(nnt.calculateEffect({ measure: "survival", comparatorRate: 89.2, treatmentRate: 95.9 }).exact, 14.93);
});

test("SPPORT point estimates reproduce the published-display calculations", () => {
  close(nnt.calculateEffect({ measure: "survival", comparatorRate: 70.9, treatmentRate: 81.3 }).exact, 9.62);
  close(nnt.calculateEffect({ measure: "survival", comparatorRate: 81.3, treatmentRate: 87.4 }).exact, 16.39);
  close(nnt.calculateEffect({ measure: "survival", comparatorRate: 70.9, treatmentRate: 87.4 }).exact, 6.06);
});

test("equal rates return no finite NNT", () => {
  assert.deepEqual(nnt.calculateEffect({ measure: "event", comparatorRate: 10, treatmentRate: 10 }), {
    direction: "no_difference", absoluteDifference: 0, metric: null, exact: null, rounded: null
  });
});

test("harm is labelled NNH and conventional rounding is upward", () => {
  const result = nnt.calculateEffect({ measure: "event", comparatorRate: 10, treatmentRate: 17 });
  assert.equal(result.metric, "NNH");
  assert.equal(result.rounded, 15);
});

test("invalid percentages are rejected", () => {
  assert.throws(() => nnt.calculateEffect({ measure: "survival", comparatorRate: -1, treatmentRate: 50 }), RangeError);
  assert.throws(() => nnt.calculateEffect({ measure: "survival", comparatorRate: 50, treatmentRate: 101 }), RangeError);
});

test("confidence interval wholly above zero transforms to an NNT interval", () => {
  const result = nnt.riskDifferenceCI({ measure: "survival", comparatorRate: 70, treatmentRate: 85, comparatorSE: 0.02, treatmentSE: 0.02 });
  assert.equal(result.interpretation, "benefit");
  assert.ok(result.nntLower < result.nntUpper);
});

test("confidence interval crossing zero remains on the risk-difference scale", () => {
  const result = nnt.riskDifferenceCI({ measure: "survival", comparatorRate: 80, treatmentRate: 82, comparatorSE: 0.03, treatmentSE: 0.03 });
  assert.equal(result.interpretation, "crosses_zero");
  assert.equal(result.intervalIsDiscontinuous, true);
  assert.equal("nntLower" in result, false);
});

test("arm confidence intervals can be converted to approximate standard errors", () => {
  const result = nnt.riskDifferenceCIFromArmCIs({
    measure: "survival", comparatorRate: 70, treatmentRate: 85,
    comparatorLower: 66, comparatorUpper: 74,
    treatmentLower: 82, treatmentUpper: 88
  });
  assert.equal(result.interpretation, "benefit");
});
