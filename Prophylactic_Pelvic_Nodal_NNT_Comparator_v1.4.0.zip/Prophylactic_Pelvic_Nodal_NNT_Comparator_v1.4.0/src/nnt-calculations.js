(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.NNTCalculator = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  function assertRate(value, name) {
    const n = Number(value);
    if (!Number.isFinite(n) || n < 0 || n > 100) {
      throw new RangeError(`${name} must be a percentage from 0 to 100.`);
    }
    return n;
  }

  function calculateEffect({ measure, comparatorRate, treatmentRate }) {
    const comparator = assertRate(comparatorRate, "Comparator rate");
    const treatment = assertRate(treatmentRate, "Treatment rate");
    if (measure !== "survival" && measure !== "event") {
      throw new TypeError("measure must be 'survival' or 'event'.");
    }
    const signedDifference = measure === "survival"
      ? treatment - comparator
      : comparator - treatment;
    if (signedDifference === 0) {
      return { direction: "no_difference", absoluteDifference: 0, metric: null, exact: null, rounded: null };
    }
    const exact = 100 / Math.abs(signedDifference);
    return {
      direction: signedDifference > 0 ? "benefit" : "harm",
      absoluteDifference: Math.abs(signedDifference),
      signedDifference,
      metric: signedDifference > 0 ? "NNT" : "NNH",
      exact,
      rounded: Math.ceil(exact)
    };
  }

  function seFrom95CI(lower, upper) {
    const lo = assertRate(lower, "CI lower bound") / 100;
    const hi = assertRate(upper, "CI upper bound") / 100;
    if (lo >= hi) throw new RangeError("CI lower bound must be below the upper bound.");
    return (hi - lo) / (2 * 1.959963984540054);
  }

  function riskDifferenceCI({ measure, comparatorRate, treatmentRate, comparatorSE, treatmentSE, confidence = 0.95 }) {
    if (confidence !== 0.95) throw new RangeError("This release supports 95% intervals only.");
    if (measure !== "survival" && measure !== "event") {
      throw new TypeError("measure must be 'survival' or 'event'.");
    }
    const comparator = assertRate(comparatorRate, "Comparator rate") / 100;
    const treatment = assertRate(treatmentRate, "Treatment rate") / 100;
    const cse = Number(comparatorSE);
    const tse = Number(treatmentSE);
    if (![cse, tse].every(x => Number.isFinite(x) && x >= 0)) {
      throw new RangeError("Standard errors must be non-negative probabilities.");
    }
    const rd = measure === "survival" ? treatment - comparator : comparator - treatment;
    const se = Math.sqrt(cse * cse + tse * tse);
    const z = 1.959963984540054;
    const lower = rd - z * se;
    const upper = rd + z * se;
    const base = { riskDifference: rd, lower, upper, standardError: se, confidence };
    if (lower > 0) {
      return { ...base, interpretation: "benefit", nntLower: 1 / upper, nntUpper: 1 / lower };
    }
    if (upper < 0) {
      return { ...base, interpretation: "harm", nnhLower: 1 / Math.abs(lower), nnhUpper: 1 / Math.abs(upper) };
    }
    return { ...base, interpretation: "crosses_zero", intervalIsDiscontinuous: true };
  }

  function riskDifferenceCIFromArmCIs(args) {
    return riskDifferenceCI({
      measure: args.measure,
      comparatorRate: args.comparatorRate,
      treatmentRate: args.treatmentRate,
      comparatorSE: seFrom95CI(args.comparatorLower, args.comparatorUpper),
      treatmentSE: seFrom95CI(args.treatmentLower, args.treatmentUpper)
    });
  }

  return { calculateEffect, seFrom95CI, riskDifferenceCI, riskDifferenceCIFromArmCIs };
});
